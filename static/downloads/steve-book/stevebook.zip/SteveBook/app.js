var express = require('express'),
	app = express(),
	server = require('http').createServer(app),
	io = require('socket.io').listen(server);
	
server.listen(8888);
io.set('log level', 1); // reduce logging

app.get('/', function(req,res){
	res.sendfile(__dirname + '/index.html');
});

var users = [];
var allClients = [];

io.sockets.on('connection', function(socket) {
	socket.on('action',function(data){
		var m = 0;
		for(var i =0; i < users.length; i++){
			if(users[i] != null && socket.username == users[i].username){
				m = i;
			}
		}	
		if(users[m] != null){
			actionHandler(data,users[m].username);
		}
	});
	

   socket.on('username',function(data){
		var m = 0;
		for(var i =0; i < users.length; i++){
			if(users[i] != null && socket.username == users[i].username){
				return;
			}
		}
		socket.username = data;
		// add user to username list and add socket connection
		users.push({username:data});
		// sends all usernames
		io.sockets.emit('users',users);
		sendMessage("<br> Stephen has joined the chat. ");
   });
   
   socket.on('disconnect', function() {
	  var m = 0;
      for(var i =0; i < users.length; i++){
		if(users[i] != null && socket.username == users[i].username){
			m = i;
		}
	  }	
	  if(users[m] != null){
		console.log("Player disconnected: " + users[m].username);
		delete users[m];
		io.sockets.emit('users',users);
	  }
   });
});

function sendMessage(data){
	console.log(data);
	io.sockets.emit('message',data);
}

function actionHandler(data,username){
	// convert to lower case
	var text = data.toLowerCase();
	console.log(text);
	
	if(text){
	text = text.replace(/<\/?[^>]+(>|$)/g, "");
		// strip tags here
	// if they ask to shout something
	text = text.replace("and","but");
	text = text.replace("clouds","butts");
	text = text.replace("cloud","butts");
	text = text.replace("stephen","butts");
	text = text.replace("hello","tooshy");
	text = text.replace("stupid","awesome");
	text = text.replace("what","hiney");
	text = text.replace("confused","ugly");
	text = text.replace("seriously","pumpkin");
	text = text.replace("name","spy alias");
	text = text.replace("wait","gallop");
	text = text.replace("explain","stupidify");
	text = text.replace("understand","wash");
	text = text.replace("don't","won't");
	text = text.replace("dont","wont");
	text = text.replace("your","you're");
	text = text.replace("you're","you");
	text = text.replace("you","your");
	
	text = text.replace("shit","poop");
	text = text.replace("piss","weewee");
	text = text.replace("fuck","donkey");
	text = text.replace("hate","rate");
	text = text.replace("cock","lollypop");
	
	
	sendMessage("<br> Stephen shouted: " + text);
	}
	
}
